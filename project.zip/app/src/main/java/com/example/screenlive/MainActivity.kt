package com.example.screenlive

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var serverInput: EditText
    private lateinit var keyInput: EditText
    private var audioGranted = false

    private val reqPermissions = 100
    private val reqProjection = 200

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        root.addView(TextView(this).apply {
            text = "بث الشاشة إلى فيسبوك\nScreen Live"
            textSize = 22f
            gravity = Gravity.CENTER
        })

        root.addView(TextView(this).apply { text = "\nServer URL:" })
        serverInput = EditText(this).apply {
            setText("rtmps://live-api-s.facebook.com:443/rtmp/")
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        root.addView(serverInput)

        root.addView(TextView(this).apply { text = "Stream Key:" })
        keyInput = EditText(this).apply {
            hint = "FB-xxxxxxxx..."
            inputType = InputType.TYPE_CLASS_TEXT
        }
        root.addView(keyInput)

        val startBtn = Button(this).apply { text = "ابدأ البث / Start" }
        val stopBtn = Button(this).apply { text = "إيقاف البث / Stop" }
        root.addView(startBtn)
        root.addView(stopBtn)

        setContentView(root)

        startBtn.setOnClickListener { onStartClicked() }
        stopBtn.setOnClickListener {
            stopService(Intent(this, StreamService::class.java))
            Toast.makeText(this, "تم الإيقاف", Toast.LENGTH_SHORT).show()
        }
    }

    private fun onStartClicked() {
        if (keyInput.text.toString().isBlank()) {
            Toast.makeText(this, "أدخل مفتاح البث (Stream Key)", Toast.LENGTH_LONG).show()
            return
        }
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = needed.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            audioGranted = true
            requestProjection()
        } else {
            requestPermissions(missing.toTypedArray(), reqPermissions)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqPermissions) {
            audioGranted =
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (!audioGranted) {
                Toast.makeText(this, "بدون إذن الميكروفون سيكون البث بدون صوت", Toast.LENGTH_LONG).show()
            }
            requestProjection()
        }
    }

    private fun requestProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), reqProjection)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqProjection) {
            if (resultCode == RESULT_OK && data != null) {
                val url = serverInput.text.toString().trim().trimEnd('/') + "/" +
                        keyInput.text.toString().trim()
                val svc = Intent(this, StreamService::class.java).apply {
                    putExtra(StreamService.EXTRA_URL, url)
                    putExtra(StreamService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(StreamService.EXTRA_DATA, data)
                    putExtra(StreamService.EXTRA_AUDIO, audioGranted)
                }
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
                Toast.makeText(this, "جارٍ بدء البث...", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "تم رفض إذن تسجيل الشاشة", Toast.LENGTH_LONG).show()
            }
        }
    }
}
