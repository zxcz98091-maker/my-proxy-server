package com.example.screenlive

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import com.pedro.common.ConnectChecker
import com.pedro.library.rtmp.RtmpDisplay

class StreamService : Service(), ConnectChecker {

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val EXTRA_AUDIO = "audio"
        private const val CHANNEL_ID = "screen_live"
        private const val NOTIF_ID = 1
    }

    private var display: RtmpDisplay? = null
    private val ui = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    private fun toast(msg: String) {
        ui.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val url = intent.getStringExtra(EXTRA_URL) ?: ""
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val audio = intent.getBooleanExtra(EXTRA_AUDIO, false)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null || url.isEmpty()) {
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground(audio)

        try {
            val d = RtmpDisplay(applicationContext, false, this)
            display = d
            d.setIntentResult(resultCode, data)

            val dm = resources.displayMetrics
            val w = 720
            var h = (w.toLong() * dm.heightPixels / dm.widthPixels).toInt()
            if (h % 2 != 0) h += 1

            val videoOk = d.prepareVideo(w, h, 30, 2500 * 1024, 0, dm.densityDpi)
            val audioOk = if (audio) d.prepareAudio(64 * 1024, 32000, true) else true

            if (videoOk && audioOk) {
                d.startStream(url)
            } else {
                toast("فشل تجهيز البث (الترميز)")
                stopSelf()
            }
        } catch (e: Exception) {
            toast("خطأ: ${e.message}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground(withMic: Boolean) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Screen Live", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Screen Live")
            .setContentText("جارٍ بث الشاشة...")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (withMic) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(NOTIF_ID, notification, type)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    override fun onDestroy() {
        try {
            display?.let { if (it.isStreaming) it.stopStream() }
        } catch (_: Exception) {
        }
        display = null
        super.onDestroy()
    }

    // ---- ConnectChecker ----
    override fun onConnectionStarted(url: String) {}
    override fun onConnectionSuccess() { toast("✅ بدأ البث المباشر") }
    override fun onConnectionFailed(reason: String) {
        toast("فشل الاتصال: $reason")
        ui.post { stopSelf() }
    }
    override fun onNewBitrate(bitrate: Long) {}
    override fun onDisconnect() { toast("انقطع البث") }
    override fun onAuthError() { toast("خطأ في المصادقة (تحقق من المفتاح)") }
    override fun onAuthSuccess() {}
}
